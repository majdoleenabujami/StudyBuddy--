const App = {


    init() {
        // Initialize state from localStorage
        State.init();

        // Initialize UI
        UI.init();

        // Load resources
        this.loadResources();

        // Setup event listeners
        this.setupEventListeners();

        // Handle initial hash
        this.handleHashChange();
    },

    /**
     * Setup all event listeners
     */
    setupEventListeners() {
        // Navigation
        document.getElementById('menuToggle').addEventListener('click', () => UI.toggleMobileMenu());

        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.getAttribute('data-section');
                window.location.hash = section;
            });
        });

        // Hash change for navigation
        window.addEventListener('hashchange', () => this.handleHashChange());

        // Task form
        document.getElementById('taskForm').addEventListener('submit', (e) => this.handleTaskFormSubmit(e));

        // Task filters
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleTaskFilterChange(e));
        });

        document.getElementById('categoryFilter').addEventListener('input', (e) => {
            State.setCategoryFilter(e.target.value);
            UI.renderTasksList();
        });

        document.getElementById('sortBy').addEventListener('change', (e) => {
            State.setTasksSort(e.target.value);
            UI.renderTasksList();
        });

        // Habit form
        document.getElementById('habitForm').addEventListener('submit', (e) => this.handleHabitFormSubmit(e));

        // Resources search and filter
        document.getElementById('resourceSearch').addEventListener('input', (e) => {
            State.setResourceSearch(e.target.value);
            UI.renderResourcesList();
        });

        document.getElementById('resourceCategory').addEventListener('change', (e) => {
            State.setResourceCategoryFilter(e.target.value);
            UI.renderResourcesList();
        });

        document.getElementById('favoritesToggle').addEventListener('click', () => {
            State.toggleFavoritesView();
            UI.renderResourcesList();
        });

        // Settings
        document.getElementById('themeToggle').addEventListener('change', (e) => {
            const theme = e.target.checked ? 'dark' : 'light';
            State.setTheme(theme);
            UI.applyTheme();
        });

        document.getElementById('saveNameBtn').addEventListener('click', () => this.handleSaveName());

        document.getElementById('resetDataBtn').addEventListener('click', () => this.handleResetData());

        // Modal close on background click
        document.getElementById('confirmModal').addEventListener('click', (e) => {
            if (e.target.id === 'confirmModal') {
                UI.hideModal();
            }
        });
    },

    /**
     * Handle hash change for navigation
     */
    handleHashChange() {
        const hash = window.location.hash.slice(1) || 'dashboard';
        UI.switchSection(hash);
    },


    loadResources() {
        State.setResourcesLoading(true);
        State.setResourcesError(false);

        fetch('resources.json')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to load resources');
                }
                return response.json();
            })
            .then(data => {
                State.setResources(data);
                State.setResourcesLoading(false);
                UI.renderResources();
            })
            .catch(error => {
                console.error('Error loading resources:', error);
                State.setResourcesError(true);
                State.setResourcesLoading(false);
                UI.renderResourcesList();
            });
    },



    /**
     * Handle task form submission
     * @param {Event} e - Form event
     */
    handleTaskFormSubmit(e) {
        e.preventDefault();

        // Get form values
        const title = document.getElementById('taskTitle').value.trim();
        const description = document.getElementById('taskDescription').value.trim();
        const dueDate = document.getElementById('taskDueDate').value;
        const priority = document.getElementById('taskPriority').value;
        const category = document.getElementById('taskCategory').value.trim();

        // Validate
        if (!this.validateTaskForm(title, dueDate)) {
            return;
        }

        // Check if editing or creating
        const editingTaskId = State.editingTaskId;

        if (editingTaskId) {
            // Update existing task
            State.updateTask(editingTaskId, {
                title,
                description,
                dueDate,
                priority,
                category
            });
        } else {
            // Create new task
            State.addTask({
                title,
                description,
                dueDate,
                priority,
                category
            });
        }

        // Clear form and refresh UI
        UI.clearTaskForm();
        UI.renderTasks();
        UI.renderDashboard();
    },

    /**
     * Validate task form
     * @param {string} title - Task title
     * @param {string} dueDate - Due date
     * @returns {boolean} Validation result
     */
    validateTaskForm(title, dueDate) {
        let isValid = true;

        if (!title) {
            UI.showError('titleError', 'العنوان مطلوب');
            isValid = false;
        } else {
            UI.clearError('titleError');
        }

        if (!dueDate) {
            UI.showError('dateError', 'تاريخ الاستحقاق مطلوب');
            isValid = false;
        } else {
            UI.clearError('dateError');
        }

        return isValid;
    },

    /**
     * Handle task toggle completion
     * @param {number} taskId - Task ID
     */
    handleTaskToggle(taskId) {
        State.toggleTaskCompletion(taskId);
        UI.renderTasks();
        UI.renderDashboard();
    },

    /**
     * Handle edit task
     * @param {number} taskId - Task ID
     */
    handleEditTask(taskId) {
        UI.fillTaskForm(taskId);
        window.location.hash = 'tasks';
        document.getElementById('taskTitle').focus();
    },

    /**
     * Handle delete task
     * @param {number} taskId - Task ID
     */
    handleDeleteTask(taskId) {
        const task = State.getTaskById(taskId);
        UI.showConfirmModal(
            'حذف المهمة',
            `هل أنت متأكد من حذف المهمة "${task.title}"؟`,
            () => {
                State.deleteTask(taskId);
                UI.renderTasks();
                UI.renderDashboard();
            }
        );
    },

    /**
     * Handle task filter change
     * @param {Event} e - Click event
     */
    handleTaskFilterChange(e) {
        const filter = e.target.getAttribute('data-filter');
        State.setTasksFilter(filter);

        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        e.target.classList.add('active');

        UI.renderTasksList();
    },



    /**
     * Handle habit form submission
     * @param {Event} e - Form event
     */
    handleHabitFormSubmit(e) {
        e.preventDefault();

        const name = document.getElementById('habitName').value.trim();
        const goal = parseInt(document.getElementById('habitGoal').value);

        // Validate
        if (!this.validateHabitForm(name, goal)) {
            return;
        }

        // Create new habit
        State.addHabit({ name, goal });

        // Clear form and refresh UI
        UI.clearHabitForm();
        UI.renderHabits();
        UI.renderDashboard();
    },

    /**
     * Validate habit form
     * @param {string} name - Habit name
     * @param {number} goal - Weekly goal
     * @returns {boolean} Validation result
     */
    validateHabitForm(name, goal) {
        let isValid = true;

        if (!name) {
            UI.showError('habitNameError', 'اسم العادة مطلوب');
            isValid = false;
        } else {
            UI.clearError('habitNameError');
        }

        if (goal < 1 || goal > 7) {
            UI.showError('habitGoalError', 'الهدف يجب أن يكون بين 1 و 7');
            isValid = false;
        } else {
            UI.clearError('habitGoalError');
        }

        return isValid;
    },

    /**
     * Handle habit day toggle
     * @param {number} habitId - Habit ID
     * @param {number} dayIndex - Day index (0-6)
     */
    handleHabitDayToggle(habitId, dayIndex) {
        const habit = State.getHabitById(habitId);
        const newStatus = !habit.progress[dayIndex];
        State.updateHabitDay(habitId, dayIndex, newStatus);
        UI.renderHabits();
        UI.renderDashboard();
    },

    /**
     * Handle delete habit
     * @param {number} habitId - Habit ID
     */
    handleDeleteHabit(habitId) {
        const habit = State.getHabitById(habitId);
        UI.showConfirmModal(
            'حذف العادة',
            `هل أنت متأكد من حذف العادة "${habit.name}"؟`,
            () => {
                State.deleteHabit(habitId);
                UI.renderHabits();
                UI.renderDashboard();
            }
        );
    },


    /**
     * Handle toggle favorite
     * @param {number} resourceId - Resource ID
     */
    handleToggleFavorite(resourceId) {
        Storage.toggleFavorite(resourceId);
        UI.renderResourcesList();
    },



    /**
     * Handle save student name
     */
    handleSaveName() {
        const name = document.getElementById('studentName').value.trim();
        State.setStudentName(name);
        alert('تم حفظ الاسم بنجاح');
    },

    /**
     * Handle reset data
     */
    handleResetData() {
        UI.showConfirmModal(
            'حذف جميع البيانات',
            'هل أنت متأكد من حذف جميع البيانات؟ لا يمكن التراجع عن هذا الإجراء.',
            () => {
                State.resetAllData();
                UI.refreshAll();
                alert('تم حذف جميع البيانات');
            }
        );
    }
};



document.addEventListener('DOMContentLoaded', () => {
    App.init();
});
