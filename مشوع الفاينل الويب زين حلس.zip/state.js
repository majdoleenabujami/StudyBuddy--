/**
 * State Module - Manages application state
 * Handles: Tasks, Habits, Filters, Current Section
 */

const State = {
    // Current section
    currentSection: 'dashboard',

    // Tasks state
    tasks: [],
    tasksFilter: 'all', // 'all', 'active', 'completed'
    tasksSort: 'dueDate', // 'dueDate', 'priority'
    categoryFilter: '',
    editingTaskId: null,

    // Habits state
    habits: [],
    editingHabitId: null,

    // Resources state
    resources: [],
    resourcesLoading: false,
    resourcesError: false,
    resourceSearch: '',
    resourceCategoryFilter: '',
    showFavoritesOnly: false,
    resourceCategories: [],

    // Settings state
    theme: 'light',
    studentName: '',

    // ============================================
    // INITIALIZATION
    // ============================================

    /**
     * Initialize state from localStorage
     */
    init() {
        this.tasks = Storage.getTasks();
        this.habits = Storage.getHabits();
        this.theme = Storage.getTheme();
        this.studentName = Storage.getStudentName();
        this.checkHabitsWeekReset();
    },

    /**
     * Check if habits week needs to be reset
     */
    checkHabitsWeekReset() {
        Storage.resetHabitsWeek();
        this.habits = Storage.getHabits();
    },

    // ============================================
    // TASKS MANAGEMENT
    // ============================================

    /**
     * Add a new task
     * @param {Object} taskData - Task data
     * @returns {Object} Added task
     */
    addTask(taskData) {
        const task = Storage.addTask(taskData);
        this.tasks = Storage.getTasks();
        return task;
    },

    /**
     * Update a task
     * @param {number} taskId - Task ID
     * @param {Object} updates - Fields to update
     * @returns {Object} Updated task
     */
    updateTask(taskId, updates) {
        const task = Storage.updateTask(taskId, updates);
        this.tasks = Storage.getTasks();
        this.editingTaskId = null;
        return task;
    },

    /**
     * Delete a task
     * @param {number} taskId - Task ID
     * @returns {boolean} Success status
     */
    deleteTask(taskId) {
        const success = Storage.deleteTask(taskId);
        this.tasks = Storage.getTasks();
        return success;
    },

    /**
     * Toggle task completion
     * @param {number} taskId - Task ID
     * @returns {Object} Updated task
     */
    toggleTaskCompletion(taskId) {
        const task = Storage.toggleTaskCompletion(taskId);
        this.tasks = Storage.getTasks();
        return task;
    },

    /**
     * Get filtered and sorted tasks
     * @returns {Array} Filtered tasks
     */
    getFilteredTasks() {
        let filtered = this.tasks;

        // Filter by completion status
        if (this.tasksFilter === 'active') {
            filtered = filtered.filter(t => !t.completed);
        } else if (this.tasksFilter === 'completed') {
            filtered = filtered.filter(t => t.completed);
        }

        // Filter by category
        if (this.categoryFilter) {
            filtered = filtered.filter(t => 
                t.category && t.category.toLowerCase().includes(this.categoryFilter.toLowerCase())
            );
        }

        // Sort
        if (this.tasksSort === 'dueDate') {
            filtered.sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));
        } else if (this.tasksSort === 'priority') {
            const priorityOrder = { 'High': 0, 'Medium': 1, 'Low': 2 };
            filtered.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
        }

        return filtered;
    },

    /**
     * Get tasks due soon (next 2 days)
     * @returns {Array} Tasks due soon
     */
    getTasksDueSoon() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const twoDaysLater = new Date(today);
        twoDaysLater.setDate(today.getDate() + 2);

        return this.tasks.filter(t => {
            if (t.completed) return false;
            const dueDate = new Date(t.dueDate);
            dueDate.setHours(0, 0, 0, 0);
            return dueDate >= today && dueDate <= twoDaysLater;
        });
    },

    /**
     * Get tasks due today or tomorrow
     * @returns {Array} Today's tasks
     */
    getTodayTasks() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(today.getDate() + 1);

        return this.tasks.filter(t => {
            if (t.completed) return false;
            const dueDate = new Date(t.dueDate);
            dueDate.setHours(0, 0, 0, 0);
            return dueDate === today || dueDate === tomorrow;
        });
    },

    /**
     * Get completion percentage
     * @returns {number} Percentage (0-100)
     */
    getCompletionPercentage() {
        if (this.tasks.length === 0) return 0;
        const completed = this.tasks.filter(t => t.completed).length;
        return Math.round((completed / this.tasks.length) * 100);
    },

    /**
     * Get completed tasks count
     * @returns {number} Count
     */
    getCompletedTasksCount() {
        return this.tasks.filter(t => t.completed).length;
    },

    /**
     * Set tasks filter
     * @param {string} filter - Filter type
     */
    setTasksFilter(filter) {
        this.tasksFilter = filter;
    },

    /**
     * Set tasks sort
     * @param {string} sort - Sort type
     */
    setTasksSort(sort) {
        this.tasksSort = sort;
    },

    /**
     * Set category filter
     * @param {string} category - Category
     */
    setCategoryFilter(category) {
        this.categoryFilter = category;
    },

    /**
     * Set editing task ID
     * @param {number|null} taskId - Task ID or null
     */
    setEditingTaskId(taskId) {
        this.editingTaskId = taskId;
    },

    /**
     * Get task by ID
     * @param {number} taskId - Task ID
     * @returns {Object|null} Task object
     */
    getTaskById(taskId) {
        return this.tasks.find(t => t.id === taskId) || null;
    },


    /**
     * Add a new habit
     * @param {Object} habitData - Habit data
     * @returns {Object} Added habit
     */
    addHabit(habitData) {
        const habit = Storage.addHabit(habitData);
        this.habits = Storage.getHabits();
        return habit;
    },

    /**
     * Update habit day
     * @param {number} habitId - Habit ID
     * @param {number} dayIndex - Day index (0-6)
     * @param {boolean} completed - Completion status
     * @returns {Object} Updated habit
     */
    updateHabitDay(habitId, dayIndex, completed) {
        const habit = Storage.updateHabitDay(habitId, dayIndex, completed);
        this.habits = Storage.getHabits();
        return habit;
    },

    /**
     * Delete a habit
     * @param {number} habitId - Habit ID
     * @returns {boolean} Success status
     */
    deleteHabit(habitId) {
        const success = Storage.deleteHabit(habitId);
        this.habits = Storage.getHabits();
        return success;
    },

    /**
     * Get weekly summary
     * @returns {Object} { completed: number, total: number }
     */
    getWeeklySummary() {
        let completed = 0;
        let total = 0;

        this.habits.forEach(habit => {
            const habitCompleted = habit.progress.filter(p => p).length;
            if (habitCompleted >= habit.goal) {
                completed++;
            }
            total++;
        });

        return { completed, total };
    },

    /**
     * Get habit streak
     * @returns {number} Streak count
     */
    getHabitStreak() {
        if (this.habits.length === 0) return 0;
        const summary = this.getWeeklySummary();
        return summary.completed;
    },

    /**
     * Get habit by ID
     * @param {number} habitId - Habit ID
     * @returns {Object|null} Habit object
     */
    getHabitById(habitId) {
        return this.habits.find(h => h.id === habitId) || null;
    },



    /**
     * Set resources
     * @param {Array} resources - Resources array
     */
    setResources(resources) {
        this.resources = resources;
        this.extractResourceCategories();
    },

    /**
     * Extract unique categories from resources
     */
    extractResourceCategories() {
        const categories = new Set();
        this.resources.forEach(r => {
            if (r.category) {
                categories.add(r.category);
            }
        });
        this.resourceCategories = Array.from(categories).sort();
    },

    /**
     * Get filtered resources
     * @returns {Array} Filtered resources
     */
    getFilteredResources() {
        let filtered = this.resources;

        // Filter by search
        if (this.resourceSearch) {
            const search = this.resourceSearch.toLowerCase();
            filtered = filtered.filter(r =>
                r.title.toLowerCase().includes(search) ||
                (r.description && r.description.toLowerCase().includes(search))
            );
        }

        // Filter by category
        if (this.resourceCategoryFilter) {
            filtered = filtered.filter(r => r.category === this.resourceCategoryFilter);
        }

        // Filter by favorites
        if (this.showFavoritesOnly) {
            const favorites = Storage.getFavorites();
            filtered = filtered.filter(r => favorites.includes(r.id));
        }

        return filtered;
    },

    /**
     * Set resource search
     * @param {string} search - Search term
     */
    setResourceSearch(search) {
        this.resourceSearch = search;
    },

    /**
     * Set resource category filter
     * @param {string} category - Category
     */
    setResourceCategoryFilter(category) {
        this.resourceCategoryFilter = category;
    },

    /**
     * Toggle favorites view
     */
    toggleFavoritesView() {
        this.showFavoritesOnly = !this.showFavoritesOnly;
    },

    /**
     * Set resources loading state
     * @param {boolean} loading - Loading state
     */
    setResourcesLoading(loading) {
        this.resourcesLoading = loading;
    },

    /**
     * Set resources error state
     * @param {boolean} error - Error state
     */
    setResourcesError(error) {
        this.resourcesError = error;
    },


    /**
     * Set theme
     * @param {string} theme - Theme ('light' or 'dark')
     */
    setTheme(theme) {
        this.theme = theme;
        Storage.setTheme(theme);
    },

    /**
     * Set student name
     * @param {string} name - Student name
     */
    setStudentName(name) {
        this.studentName = name;
        Storage.setStudentName(name);
    },

    /**
     * Reset all data
     */
    resetAllData() {
        Storage.clearAllData();
        this.tasks = [];
        this.habits = [];
        this.theme = 'light';
        this.studentName = '';
        this.resourceSearch = '';
        this.resourceCategoryFilter = '';
        this.showFavoritesOnly = false;
    },



    /**
     * Set current section
     * @param {string} section - Section name
     */
    setCurrentSection(section) {
        this.currentSection = section;
    },

    /**
     * Get current section
     * @returns {string} Current section
     */
    getCurrentSection() {
        return this.currentSection;
    }
};
