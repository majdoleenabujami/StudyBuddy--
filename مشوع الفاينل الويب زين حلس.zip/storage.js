
const Storage = {
    // Keys
    KEYS: {
        TASKS: 'tasks',
        HABITS: 'habits',
        FAVORITES: 'favorites',
        SETTINGS: 'settings'
    },


    /**
     * Get all tasks from localStorage
     * @returns {Array} Array of task objects
     */
    getTasks() {
        const tasks = localStorage.getItem(this.KEYS.TASKS);
        return tasks ? JSON.parse(tasks) : [];
    },

    /**
     * Save tasks to localStorage
     * @param {Array} tasks - Array of task objects
     */
    saveTasks(tasks) {
        localStorage.setItem(this.KEYS.TASKS, JSON.stringify(tasks));
    },

    /**
     * Add a new task
     * @param {Object} task - Task object
     * @returns {Object} The added task with ID
     */
    addTask(task) {
        const tasks = this.getTasks();
        const newTask = {
            ...task,
            id: Date.now(),
            completed: false,
            createdAt: new Date().toISOString()
        };
        tasks.push(newTask);
        this.saveTasks(tasks);
        return newTask;
    },

    /**
     * Update an existing task
     * @param {number} taskId - Task ID
     * @param {Object} updates - Fields to update
     * @returns {Object} Updated task
     */
    updateTask(taskId, updates) {
        const tasks = this.getTasks();
        const taskIndex = tasks.findIndex(t => t.id === taskId);
        if (taskIndex !== -1) {
            tasks[taskIndex] = { ...tasks[taskIndex], ...updates };
            this.saveTasks(tasks);
            return tasks[taskIndex];
        }
        return null;
    },

    /**
     * Delete a task
     * @param {number} taskId - Task ID
     * @returns {boolean} Success status
     */
    deleteTask(taskId) {
        const tasks = this.getTasks();
        const filteredTasks = tasks.filter(t => t.id !== taskId);
        this.saveTasks(filteredTasks);
        return tasks.length !== filteredTasks.length;
    },

    /**
     * Toggle task completion status
     * @param {number} taskId - Task ID
     * @returns {Object} Updated task
     */
    toggleTaskCompletion(taskId) {
        const tasks = this.getTasks();
        const task = tasks.find(t => t.id === taskId);
        if (task) {
            task.completed = !task.completed;
            this.saveTasks(tasks);
            return task;
        }
        return null;
    },



    /**
     * Get all habits from localStorage
     * @returns {Array} Array of habit objects
     */
    getHabits() {
        const habits = localStorage.getItem(this.KEYS.HABITS);
        return habits ? JSON.parse(habits) : [];
    },

    /**
     * Save habits to localStorage
     * @param {Array} habits - Array of habit objects
     */
    saveHabits(habits) {
        localStorage.setItem(this.KEYS.HABITS, JSON.stringify(habits));
    },

    /**
     * Add a new habit
     * @param {Object} habit - Habit object
     * @returns {Object} The added habit with ID
     */
    addHabit(habit) {
        const habits = this.getHabits();
        const today = new Date();
        const weekStart = new Date(today);
        weekStart.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1)); // Monday start

        const newHabit = {
            ...habit,
            id: Date.now(),
            progress: [false, false, false, false, false, false, false],
            weekStartDate: weekStart.toISOString().split('T')[0],
            createdAt: new Date().toISOString()
        };
        habits.push(newHabit);
        this.saveHabits(habits);
        return newHabit;
    },

    /**
     * Update habit progress for a specific day
     * @param {number} habitId - Habit ID
     * @param {number} dayIndex - Day index (0-6)
     * @param {boolean} completed - Completion status
     * @returns {Object} Updated habit
     */
    updateHabitDay(habitId, dayIndex, completed) {
        const habits = this.getHabits();
        const habit = habits.find(h => h.id === habitId);
        if (habit && dayIndex >= 0 && dayIndex < 7) {
            habit.progress[dayIndex] = completed;
            this.saveHabits(habits);
            return habit;
        }
        return null;
    },

    /**
     * Delete a habit
     * @param {number} habitId - Habit ID
     * @returns {boolean} Success status
     */
    deleteHabit(habitId) {
        const habits = this.getHabits();
        const filteredHabits = habits.filter(h => h.id !== habitId);
        this.saveHabits(filteredHabits);
        return habits.length !== filteredHabits.length;
    },

    /**
     * Reset habits for a new week
     * @returns {void}
     */
    resetHabitsWeek() {
        const habits = this.getHabits();
        const today = new Date();
        const weekStart = new Date(today);
        weekStart.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1));
        const weekStartStr = weekStart.toISOString().split('T')[0];

        habits.forEach(habit => {
            if (habit.weekStartDate !== weekStartStr) {
                habit.weekStartDate = weekStartStr;
                habit.progress = [false, false, false, false, false, false, false];
            }
        });

        this.saveHabits(habits);
    },


    /**
     * Get all favorite resource IDs
     * @returns {Array} Array of resource IDs
     */
    getFavorites() {
        const favorites = localStorage.getItem(this.KEYS.FAVORITES);
        return favorites ? JSON.parse(favorites) : [];
    },

    /**
     * Save favorites to localStorage
     * @param {Array} favorites - Array of resource IDs
     */
    saveFavorites(favorites) {
        localStorage.setItem(this.KEYS.FAVORITES, JSON.stringify(favorites));
    },

    /**
     * Add a resource to favorites
     * @param {number} resourceId - Resource ID
     * @returns {boolean} Success status
     */
    addFavorite(resourceId) {
        const favorites = this.getFavorites();
        if (!favorites.includes(resourceId)) {
            favorites.push(resourceId);
            this.saveFavorites(favorites);
            return true;
        }
        return false;
    },

    /**
     * Remove a resource from favorites
     * @param {number} resourceId - Resource ID
     * @returns {boolean} Success status
     */
    removeFavorite(resourceId) {
        const favorites = this.getFavorites();
        const index = favorites.indexOf(resourceId);
        if (index !== -1) {
            favorites.splice(index, 1);
            this.saveFavorites(favorites);
            return true;
        }
        return false;
    },

    /**
     * Toggle favorite status
     * @param {number} resourceId - Resource ID
     * @returns {boolean} New favorite status
     */
    toggleFavorite(resourceId) {
        const favorites = this.getFavorites();
        if (favorites.includes(resourceId)) {
            this.removeFavorite(resourceId);
            return false;
        } else {
            this.addFavorite(resourceId);
            return true;
        }
    },

    /**
     * Check if a resource is favorited
     * @param {number} resourceId - Resource ID
     * @returns {boolean} Favorite status
     */
    isFavorited(resourceId) {
        return this.getFavorites().includes(resourceId);
    },



    /**
     * Get all settings
     * @returns {Object} Settings object
     */
    getSettings() {
        const settings = localStorage.getItem(this.KEYS.SETTINGS);
        return settings ? JSON.parse(settings) : { theme: 'light', studentName: '' };
    },

    /**
     * Save settings to localStorage
     * @param {Object} settings - Settings object
     */
    saveSettings(settings) {
        localStorage.setItem(this.KEYS.SETTINGS, JSON.stringify(settings));
    },

    /**
     * Update a specific setting
     * @param {string} key - Setting key
     * @param {*} value - Setting value
     */
    updateSetting(key, value) {
        const settings = this.getSettings();
        settings[key] = value;
        this.saveSettings(settings);
    },

    /**
     * Get theme setting
     * @returns {string} Theme ('light' or 'dark')
     */
    getTheme() {
        return this.getSettings().theme;
    },

    /**
     * Set theme
     * @param {string} theme - Theme ('light' or 'dark')
     */
    setTheme(theme) {
        this.updateSetting('theme', theme);
    },

    /**
     * Get student name
     * @returns {string} Student name
     */
    getStudentName() {
        return this.getSettings().studentName;
    },

    /**
     * Set student name
     * @param {string} name - Student name
     */
    setStudentName(name) {
        this.updateSetting('studentName', name);
    },


    /**
     * Clear all data from localStorage
     */
    clearAllData() {
        localStorage.removeItem(this.KEYS.TASKS);
        localStorage.removeItem(this.KEYS.HABITS);
        localStorage.removeItem(this.KEYS.FAVORITES);
        localStorage.removeItem(this.KEYS.SETTINGS);
    },

    /**
     * Export all data as JSON
     * @returns {Object} All data
     */
    exportData() {
        return {
            tasks: this.getTasks(),
            habits: this.getHabits(),
            favorites: this.getFavorites(),
            settings: this.getSettings()
        };
    }
};
