
const UI = {
    /**
     * Initialize UI
     */
    init() {
        this.applyTheme();
        this.renderDashboard();
        this.renderTasks();
        this.renderHabits();
        this.renderResources();
        this.renderSettings();
        this.updateStudentName();
    },

    /**
     * Apply theme to body
     */
    applyTheme() {
        const body = document.body;
        if (State.theme === 'dark') {
            body.classList.add('dark-mode');
        } else {
            body.classList.remove('dark-mode');
        }
    },

    // DASHBOARD RENDERING

    /**
     * Render dashboard section
     */
    renderDashboard() {
        this.updateDashboardCards();
        this.renderTodayTasks();
        this.updateProgressBar();
    },

    /**
     * Update dashboard summary cards
     */
    updateDashboardCards() {
        const tasksDueSoon = State.getTasksDueSoon();
        const completedTasks = State.getCompletedTasksCount();
        const habitStreak = State.getHabitStreak();

        document.getElementById('tasksDueSoon').textContent = tasksDueSoon.length;
        document.getElementById('completedTasks').textContent = completedTasks;
        document.getElementById('habitStreak').textContent = habitStreak;
    },

    /**
     * Render today's tasks
     */
    renderTodayTasks() {
        const container = document.getElementById('todayTasks');
        const todayTasks = State.getTodayTasks();

        if (todayTasks.length === 0) {
            container.innerHTML = '<p class="empty-message">لا توجد مهام لليوم</p>';
            return;
        }

        container.innerHTML = todayTasks.map(task => `
            <div class="task-item ${task.completed ? 'completed' : ''}">
                <div class="task-content">
                    <div class="task-header">
                        <input type="checkbox" class="task-checkbox" 
                               ${task.completed ? 'checked' : ''} 
                               data-task-id="${task.id}" 
                               onchange="App.handleTaskToggle(${task.id})">
                        <h4 class="task-title">${this.escapeHtml(task.title)}</h4>
                    </div>
                    <div class="task-meta">
                        <span class="task-meta-item">📅 ${new Date(task.dueDate).toLocaleDateString('ar-SA')}</span>
                        <span class="task-priority ${task.priority.toLowerCase()}">${task.priority}</span>
                    </div>
                </div>
            </div>
        `).join('');
    },

    /**
     * Update progress bar
     */
    updateProgressBar() {
        const percentage = State.getCompletionPercentage();
        const progressFill = document.getElementById('progressFill');
        const progressPercent = document.getElementById('progressPercent');

        progressFill.style.width = percentage + '%';
        progressPercent.textContent = percentage;
    },


    /**
     * Render tasks section
     */
    renderTasks() {
        this.renderTasksList();
    },

    /**
     * Render tasks list
     */
    renderTasksList() {
        const container = document.getElementById('tasksList');
        const tasks = State.getFilteredTasks();

        if (tasks.length === 0) {
            container.innerHTML = '<p class="empty-message">لا توجد مهام</p>';
            return;
        }

        container.innerHTML = tasks.map(task => `
            <div class="task-item ${task.completed ? 'completed' : ''}">
                <div class="task-content">
                    <div class="task-header">
                        <input type="checkbox" class="task-checkbox" 
                               ${task.completed ? 'checked' : ''} 
                               data-task-id="${task.id}" 
                               onchange="App.handleTaskToggle(${task.id})">
                        <h4 class="task-title">${this.escapeHtml(task.title)}</h4>
                    </div>
                    ${task.description ? `<p style="margin: 0.5rem 0; color: var(--text-secondary);">${this.escapeHtml(task.description)}</p>` : ''}
                    <div class="task-meta">
                        <span class="task-meta-item">📅 ${new Date(task.dueDate).toLocaleDateString('ar-SA')}</span>
                        <span class="task-priority ${task.priority.toLowerCase()}">${task.priority}</span>
                        ${task.category ? `<span class="task-meta-item">🏷️ ${this.escapeHtml(task.category)}</span>` : ''}
                    </div>
                </div>
                <div class="task-actions">
                    <button class="task-btn task-btn-edit" onclick="App.handleEditTask(${task.id})">تعديل</button>
                    <button class="task-btn task-btn-delete" onclick="App.handleDeleteTask(${task.id})">حذف</button>
                </div>
            </div>
        `).join('');
    },

    /**
     * Render habits section
     */
    renderHabits() {
        this.renderHabitsList();
        this.updateWeeklySummary();
    },

    /**
     * Render habits list
     */
    renderHabitsList() {
        const container = document.getElementById('habitsList');
        const habits = State.habits;

        if (habits.length === 0) {
            container.innerHTML = '<p class="empty-message">لم تضف أي عادات بعد</p>';
            return;
        }

        container.innerHTML = habits.map(habit => {
            const daysLabels = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
            const completedDays = habit.progress.filter(p => p).length;

            return `
                <div class="habit-card">
                    <div class="habit-header">
                        <h4 class="habit-title">${this.escapeHtml(habit.name)}</h4>
                        <span class="habit-goal">${completedDays}/${habit.goal}</span>
                    </div>
                    <div class="week-days">
                        ${habit.progress.map((completed, index) => `
                            <button class="day-button ${completed ? 'completed' : ''}" 
                                    onclick="App.handleHabitDayToggle(${habit.id}, ${index})"
                                    title="${daysLabels[index]}">
                                ${daysLabels[index].substring(0, 1)}
                            </button>
                        `).join('')}
                    </div>
                    <button class="habit-delete" onclick="App.handleDeleteHabit(${habit.id})">حذف العادة</button>
                </div>
            `;
        }).join('');
    },

    /**
     * Update weekly summary
     */
    updateWeeklySummary() {
        const summary = State.getWeeklySummary();
        document.getElementById('weeklySummary').textContent = 
            `${summary.completed} / ${summary.total} أهداف مكتملة`;
    },

    /**
     * Render resources section
     */
    renderResources() {
        this.updateResourceCategories();
        this.renderResourcesList();
    },

    /**
     * Update resource categories dropdown
     */
    updateResourceCategories() {
        const select = document.getElementById('resourceCategory');
        const currentValue = select.value;

        select.innerHTML = '<option value="">جميع الفئات</option>' +
            State.resourceCategories.map(cat => 
                `<option value="${cat}">${cat}</option>`
            ).join('');

        select.value = currentValue;
    },

    /**
     * Render resources list
     */
    renderResourcesList() {
        const container = document.getElementById('resourcesList');
        const loadingEl = document.getElementById('resourcesLoading');
        const errorEl = document.getElementById('resourcesError');

        if (State.resourcesLoading) {
            loadingEl.style.display = 'block';
            errorEl.style.display = 'none';
            container.innerHTML = '';
            return;
        }

        if (State.resourcesError) {
            loadingEl.style.display = 'none';
            errorEl.style.display = 'block';
            container.innerHTML = '';
            return;
        }

        loadingEl.style.display = 'none';
        errorEl.style.display = 'none';

        const resources = State.getFilteredResources();

        if (resources.length === 0) {
            container.innerHTML = '<p class="empty-message">لا توجد موارد</p>';
            return;
        }

        const favorites = Storage.getFavorites();

        container.innerHTML = resources.map(resource => `
            <div class="resource-card">
                <div class="resource-header">
                    <h4 class="resource-title">${this.escapeHtml(resource.title)}</h4>
                    <button class="resource-favorite ${favorites.includes(resource.id) ? 'favorited' : ''}" 
                            onclick="App.handleToggleFavorite(${resource.id})"
                            title="إضافة للمفضلة">
                        ${favorites.includes(resource.id) ? '⭐' : '☆'}
                    </button>
                </div>
                <span class="resource-category">${this.escapeHtml(resource.category)}</span>
                ${resource.description ? `<p class="resource-description">${this.escapeHtml(resource.description)}</p>` : ''}
                <a href="${resource.link}" target="_blank" class="resource-link">
                    الذهاب للمورد ↗
                </a>
            </div>
        `).join('');
    },

    /**
     * Render settings section
     */
    renderSettings() {
        const themeToggle = document.getElementById('themeToggle');
        const studentNameInput = document.getElementById('studentName');

        themeToggle.checked = State.theme === 'dark';
        studentNameInput.value = State.studentName;
    },

    /**
     * Update student name display
     */
    updateStudentName() {
        // Can be used to update header or other places showing student name
    },


    /**
     * Show confirmation modal
     * @param {string} title - Modal title
     * @param {string} message - Modal message
     * @param {Function} onConfirm - Callback on confirm
     */
    showConfirmModal(title, message, onConfirm) {
        const modal = document.getElementById('confirmModal');
        document.getElementById('modalTitle').textContent = title;
        document.getElementById('modalMessage').textContent = message;

        const confirmBtn = document.getElementById('modalConfirm');
        const cancelBtn = document.getElementById('modalCancel');

        // Remove old listeners
        const newConfirmBtn = confirmBtn.cloneNode(true);
        const newCancelBtn = cancelBtn.cloneNode(true);
        confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);
        cancelBtn.parentNode.replaceChild(newCancelBtn, cancelBtn);

        newConfirmBtn.addEventListener('click', () => {
            modal.style.display = 'none';
            onConfirm();
        });

        newCancelBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        modal.style.display = 'flex';
    },

    /**
     * Hide modal
     */
    hideModal() {
        document.getElementById('confirmModal').style.display = 'none';
    },

    /**
     * Switch to section
     * @param {string} sectionName - Section name
     */
    switchSection(sectionName) {
        // Hide all sections
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });

        // Show selected section
        const section = document.getElementById(sectionName);
        if (section) {
            section.classList.add('active');
        }

        // Update navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });

        const activeLink = document.querySelector(`[data-section="${sectionName}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }

        // Close mobile menu
        const nav = document.getElementById('appNav');
        nav.classList.remove('active');

        // Update state
        State.setCurrentSection(sectionName);
    },

    /**
     * Toggle mobile menu
     */
    toggleMobileMenu() {
        const nav = document.getElementById('appNav');
        nav.classList.toggle('active');
    },


    /**
     * Clear task form
     */
    clearTaskForm() {
        document.getElementById('taskForm').reset();
        document.querySelectorAll('.error-message').forEach(el => {
            el.textContent = '';
        });
        State.setEditingTaskId(null);
    },

    /**
     * Fill task form for editing
     * @param {number} taskId - Task ID
     */
    fillTaskForm(taskId) {
        const task = State.getTaskById(taskId);
        if (!task) return;

        document.getElementById('taskTitle').value = task.title;
        document.getElementById('taskDescription').value = task.description || '';
        document.getElementById('taskDueDate').value = task.dueDate;
        document.getElementById('taskPriority').value = task.priority;
        document.getElementById('taskCategory').value = task.category || '';

        State.setEditingTaskId(taskId);
    },

    /**
     * Clear habit form
     */
    clearHabitForm() {
        document.getElementById('habitForm').reset();
        document.getElementById('habitGoal').value = 5;
        document.querySelectorAll('.error-message').forEach(el => {
            el.textContent = '';
        });
    },


    /**
     * Escape HTML special characters
     * @param {string} text - Text to escape
     * @returns {string} Escaped text
     */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },

    /**
     * Format date to locale string
     * @param {string} dateStr - Date string
     * @returns {string} Formatted date
     */
    formatDate(dateStr) {
        return new Date(dateStr).toLocaleDateString('ar-SA');
    },

    /**
     * Show error message
     * @param {string} elementId - Element ID
     * @param {string} message - Error message
     */
    showError(elementId, message) {
        const el = document.getElementById(elementId);
        if (el) {
            el.textContent = message;
        }
    },

    /**
     * Clear error message
     * @param {string} elementId - Element ID
     */
    clearError(elementId) {
        const el = document.getElementById(elementId);
        if (el) {
            el.textContent = '';
        }
    },

    
    /**
     * Refresh all UI
     */
    refreshAll() {
        this.renderDashboard();
        this.renderTasks();
        this.renderHabits();
        this.renderResources();
        this.renderSettings();
    }
};
